## Authors

The main author of Fix is François Pottier (Inria Paris).

Some modules, including
`Fix.CompactQueue`,
`Fix.DataFlow.ForCustomMaps`
`Fix.Indexing`,
`Fix.Partition`,
`Fix.Minimize`
have been contributed by Frédéric Bour
and thoroughly reviewed by François Pottier.
