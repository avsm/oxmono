(******************************************************************************)
(*                                                                            *)
(*                                    Fix                                     *)
(*                                                                            *)
(*                       François Pottier, Inria Paris                        *)
(*                                                                            *)
(*  Copyright Inria. All rights reserved. This file is distributed under the  *)
(*  terms of the GNU Library General Public License version 2, with a         *)
(*  special exception on linking, as described in the file LICENSE.           *)
(*                                                                            *)
(******************************************************************************)

type property =
    bool

let bottom =
  false

let equal (b1 : bool) (b2 : bool) =
  b1 = b2

let leq (b1 : bool) (b2 : bool) =
  b1 <= b2

let is_maximal b =
  b

let leq_join b1 b2 =
  b1 || b2

let join =
  leq_join
